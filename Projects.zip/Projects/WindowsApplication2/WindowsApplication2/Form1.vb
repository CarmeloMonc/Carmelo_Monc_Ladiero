﻿Public Class Form1


    Private Sub Evaluate_btn_Click(sender As Object, e As EventArgs) Handles Evaluate_btn.Click
        Dim Age As Integer = Convert.ToDecimal(age_txtbox.Text)
        If Age >= 100 Then
            MsgBox("DINOSAUR AGE")
        ElseIf Age >= 90 Then
            MsgBox("Century Age")
        ElseIf Age >= 80 Then
            MsgBox("GrandFather Age")
        ElseIf Age >= 60 Then
            MsgBox("Senior Citizen Age")
        ElseIf Age >= 45 Then
            MsgBox("Middle Age")
        ElseIf Age >= 30 Then
            MsgBox("Young")
        Else
            MsgBox("Unknown Age")
        End If
    End Sub
End Class
