﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.un_txtbox = New System.Windows.Forms.TextBox()
        Me.password_txtbox = New System.Windows.Forms.TextBox()
        Me.email_txtbox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SignIn_btn = New System.Windows.Forms.Button()
        Me.Cancel_btn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'un_txtbox
        '
        Me.un_txtbox.BackColor = System.Drawing.SystemColors.Window
        Me.un_txtbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.un_txtbox.Location = New System.Drawing.Point(93, 128)
        Me.un_txtbox.Name = "un_txtbox"
        Me.un_txtbox.Size = New System.Drawing.Size(388, 29)
        Me.un_txtbox.TabIndex = 0
        '
        'password_txtbox
        '
        Me.password_txtbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.password_txtbox.Location = New System.Drawing.Point(93, 188)
        Me.password_txtbox.Name = "password_txtbox"
        Me.password_txtbox.Size = New System.Drawing.Size(388, 29)
        Me.password_txtbox.TabIndex = 1
        '
        'email_txtbox
        '
        Me.email_txtbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.email_txtbox.Location = New System.Drawing.Point(93, 259)
        Me.email_txtbox.Name = "email_txtbox"
        Me.email_txtbox.Size = New System.Drawing.Size(388, 29)
        Me.email_txtbox.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(130, 102)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 24)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Username:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(130, 161)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 24)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Password:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(130, 232)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 24)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Email:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(101, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 33)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Sign In:"
        '
        'Label6
        '
        Me.Label6.Image = Global.Testapplication.My.Resources.Resources.mail_FILL0_wght400_GRAD0_opsz24
        Me.Label6.Location = New System.Drawing.Point(104, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 23)
        Me.Label6.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.Image = Global.Testapplication.My.Resources.Resources.person_FILL0_wght400_GRAD0_opsz24
        Me.Label5.Location = New System.Drawing.Point(105, 102)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(23, 23)
        Me.Label5.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.Image = Global.Testapplication.My.Resources.Resources.lock_FILL0_wght400_GRAD0_opsz24
        Me.Label4.Location = New System.Drawing.Point(104, 161)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 23)
        Me.Label4.TabIndex = 8
        '
        'SignIn_btn
        '
        Me.SignIn_btn.BackColor = System.Drawing.Color.Silver
        Me.SignIn_btn.Font = New System.Drawing.Font("Century", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SignIn_btn.Image = Global.Testapplication.My.Resources.Resources.login_FILL0_wght400_GRAD0_opsz24
        Me.SignIn_btn.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.SignIn_btn.Location = New System.Drawing.Point(323, 310)
        Me.SignIn_btn.Name = "SignIn_btn"
        Me.SignIn_btn.Size = New System.Drawing.Size(117, 34)
        Me.SignIn_btn.TabIndex = 4
        Me.SignIn_btn.Text = "Sign In "
        Me.SignIn_btn.UseVisualStyleBackColor = False
        '
        'Cancel_btn
        '
        Me.Cancel_btn.BackColor = System.Drawing.Color.Silver
        Me.Cancel_btn.Font = New System.Drawing.Font("Century", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_btn.Image = Global.Testapplication.My.Resources.Resources.cancel_FILL0_wght400_GRAD0_opsz24
        Me.Cancel_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Cancel_btn.Location = New System.Drawing.Point(134, 310)
        Me.Cancel_btn.Name = "Cancel_btn"
        Me.Cancel_btn.Size = New System.Drawing.Size(127, 34)
        Me.Cancel_btn.TabIndex = 3
        Me.Cancel_btn.Text = "Cancel"
        Me.Cancel_btn.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateBlue
        Me.ClientSize = New System.Drawing.Size(588, 485)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SignIn_btn)
        Me.Controls.Add(Me.Cancel_btn)
        Me.Controls.Add(Me.email_txtbox)
        Me.Controls.Add(Me.password_txtbox)
        Me.Controls.Add(Me.un_txtbox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sign In"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents un_txtbox As TextBox
    Friend WithEvents password_txtbox As TextBox
    Friend WithEvents email_txtbox As TextBox
    Friend WithEvents Cancel_btn As Button
    Friend WithEvents SignIn_btn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
