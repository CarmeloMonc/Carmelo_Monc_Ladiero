﻿Public Class Form2
    Private Sub email_txtbox_TextChanged(sender As Object, e As EventArgs) Handles email_txtbox.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form2_Click(sender As Object, e As EventArgs) Handles MyBase.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub password_txtbox_TextChanged(sender As Object, e As EventArgs) Handles password_txtbox.TextChanged

    End Sub

    Private Sub Cancel_btn_Click(sender As Object, e As EventArgs) Handles Cancel_btn.Click

    End Sub
End Class