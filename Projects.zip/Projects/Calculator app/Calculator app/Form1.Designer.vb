﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.one_btn = New System.Windows.Forms.Button()
        Me.two_btn = New System.Windows.Forms.Button()
        Me.nine_btn = New System.Windows.Forms.Button()
        Me.zero_btn = New System.Windows.Forms.Button()
        Me.seven_btn = New System.Windows.Forms.Button()
        Me.eight_btn = New System.Windows.Forms.Button()
        Me.six_btn = New System.Windows.Forms.Button()
        Me.multiply_btn = New System.Windows.Forms.Button()
        Me.four_btn = New System.Windows.Forms.Button()
        Me.five_btn = New System.Windows.Forms.Button()
        Me.three_btn = New System.Windows.Forms.Button()
        Me.equal_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.minus_btn = New System.Windows.Forms.Button()
        Me.divide_btn = New System.Windows.Forms.Button()
        Me.clear_btn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt_total
        '
        Me.txt_total.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total.Location = New System.Drawing.Point(115, 54)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.Size = New System.Drawing.Size(270, 29)
        Me.txt_total.TabIndex = 0
        '
        'one_btn
        '
        Me.one_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.one_btn.Location = New System.Drawing.Point(115, 200)
        Me.one_btn.Name = "one_btn"
        Me.one_btn.Size = New System.Drawing.Size(63, 35)
        Me.one_btn.TabIndex = 1
        Me.one_btn.Text = "1"
        Me.one_btn.UseVisualStyleBackColor = True
        '
        'two_btn
        '
        Me.two_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.two_btn.Location = New System.Drawing.Point(184, 200)
        Me.two_btn.Name = "two_btn"
        Me.two_btn.Size = New System.Drawing.Size(63, 35)
        Me.two_btn.TabIndex = 2
        Me.two_btn.Text = "2"
        Me.two_btn.UseVisualStyleBackColor = True
        '
        'nine_btn
        '
        Me.nine_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nine_btn.Location = New System.Drawing.Point(253, 118)
        Me.nine_btn.Name = "nine_btn"
        Me.nine_btn.Size = New System.Drawing.Size(63, 35)
        Me.nine_btn.TabIndex = 3
        Me.nine_btn.Text = "9"
        Me.nine_btn.UseVisualStyleBackColor = True
        '
        'zero_btn
        '
        Me.zero_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zero_btn.Location = New System.Drawing.Point(322, 118)
        Me.zero_btn.Name = "zero_btn"
        Me.zero_btn.Size = New System.Drawing.Size(63, 35)
        Me.zero_btn.TabIndex = 4
        Me.zero_btn.Text = "0"
        Me.zero_btn.UseVisualStyleBackColor = True
        '
        'seven_btn
        '
        Me.seven_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.seven_btn.Location = New System.Drawing.Point(115, 118)
        Me.seven_btn.Name = "seven_btn"
        Me.seven_btn.Size = New System.Drawing.Size(63, 35)
        Me.seven_btn.TabIndex = 5
        Me.seven_btn.Text = "7"
        Me.seven_btn.UseVisualStyleBackColor = True
        '
        'eight_btn
        '
        Me.eight_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eight_btn.Location = New System.Drawing.Point(184, 118)
        Me.eight_btn.Name = "eight_btn"
        Me.eight_btn.Size = New System.Drawing.Size(63, 35)
        Me.eight_btn.TabIndex = 6
        Me.eight_btn.Text = "8"
        Me.eight_btn.UseVisualStyleBackColor = True
        '
        'six_btn
        '
        Me.six_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.six_btn.Location = New System.Drawing.Point(253, 159)
        Me.six_btn.Name = "six_btn"
        Me.six_btn.Size = New System.Drawing.Size(63, 35)
        Me.six_btn.TabIndex = 7
        Me.six_btn.Text = "6"
        Me.six_btn.UseVisualStyleBackColor = True
        '
        'multiply_btn
        '
        Me.multiply_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.multiply_btn.Location = New System.Drawing.Point(322, 159)
        Me.multiply_btn.Name = "multiply_btn"
        Me.multiply_btn.Size = New System.Drawing.Size(63, 35)
        Me.multiply_btn.TabIndex = 8
        Me.multiply_btn.Text = "*"
        Me.multiply_btn.UseVisualStyleBackColor = True
        '
        'four_btn
        '
        Me.four_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.four_btn.Location = New System.Drawing.Point(115, 159)
        Me.four_btn.Name = "four_btn"
        Me.four_btn.Size = New System.Drawing.Size(63, 35)
        Me.four_btn.TabIndex = 9
        Me.four_btn.Text = "4"
        Me.four_btn.UseVisualStyleBackColor = True
        '
        'five_btn
        '
        Me.five_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.five_btn.Location = New System.Drawing.Point(184, 159)
        Me.five_btn.Name = "five_btn"
        Me.five_btn.Size = New System.Drawing.Size(63, 35)
        Me.five_btn.TabIndex = 10
        Me.five_btn.Text = "5"
        Me.five_btn.UseVisualStyleBackColor = True
        '
        'three_btn
        '
        Me.three_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.three_btn.Location = New System.Drawing.Point(253, 200)
        Me.three_btn.Name = "three_btn"
        Me.three_btn.Size = New System.Drawing.Size(63, 35)
        Me.three_btn.TabIndex = 11
        Me.three_btn.Text = "3"
        Me.three_btn.UseVisualStyleBackColor = True
        '
        'equal_btn
        '
        Me.equal_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equal_btn.Location = New System.Drawing.Point(322, 200)
        Me.equal_btn.Name = "equal_btn"
        Me.equal_btn.Size = New System.Drawing.Size(63, 35)
        Me.equal_btn.TabIndex = 12
        Me.equal_btn.Text = "="
        Me.equal_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.add_btn.Location = New System.Drawing.Point(115, 241)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(63, 35)
        Me.add_btn.TabIndex = 13
        Me.add_btn.Text = "+"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'minus_btn
        '
        Me.minus_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minus_btn.Location = New System.Drawing.Point(184, 241)
        Me.minus_btn.Name = "minus_btn"
        Me.minus_btn.Size = New System.Drawing.Size(63, 35)
        Me.minus_btn.TabIndex = 14
        Me.minus_btn.Text = "-"
        Me.minus_btn.UseVisualStyleBackColor = True
        '
        'divide_btn
        '
        Me.divide_btn.Location = New System.Drawing.Point(253, 241)
        Me.divide_btn.Name = "divide_btn"
        Me.divide_btn.Size = New System.Drawing.Size(63, 35)
        Me.divide_btn.TabIndex = 15
        Me.divide_btn.Text = "/"
        Me.divide_btn.UseVisualStyleBackColor = True
        '
        'clear_btn
        '
        Me.clear_btn.Location = New System.Drawing.Point(322, 241)
        Me.clear_btn.Name = "clear_btn"
        Me.clear_btn.Size = New System.Drawing.Size(63, 35)
        Me.clear_btn.TabIndex = 16
        Me.clear_btn.Text = "C"
        Me.clear_btn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(491, 323)
        Me.Controls.Add(Me.clear_btn)
        Me.Controls.Add(Me.divide_btn)
        Me.Controls.Add(Me.minus_btn)
        Me.Controls.Add(Me.add_btn)
        Me.Controls.Add(Me.equal_btn)
        Me.Controls.Add(Me.three_btn)
        Me.Controls.Add(Me.five_btn)
        Me.Controls.Add(Me.four_btn)
        Me.Controls.Add(Me.multiply_btn)
        Me.Controls.Add(Me.six_btn)
        Me.Controls.Add(Me.eight_btn)
        Me.Controls.Add(Me.seven_btn)
        Me.Controls.Add(Me.zero_btn)
        Me.Controls.Add(Me.nine_btn)
        Me.Controls.Add(Me.two_btn)
        Me.Controls.Add(Me.one_btn)
        Me.Controls.Add(Me.txt_total)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_total As TextBox
    Friend WithEvents one_btn As Button
    Friend WithEvents two_btn As Button
    Friend WithEvents nine_btn As Button
    Friend WithEvents zero_btn As Button
    Friend WithEvents seven_btn As Button
    Friend WithEvents eight_btn As Button
    Friend WithEvents six_btn As Button
    Friend WithEvents multiply_btn As Button
    Friend WithEvents four_btn As Button
    Friend WithEvents five_btn As Button
    Friend WithEvents three_btn As Button
    Friend WithEvents equal_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents minus_btn As Button
    Friend WithEvents divide_btn As Button
    Friend WithEvents clear_btn As Button
End Class
