﻿Public Class Form1
    Dim firstval As Double
    Dim secondval As Double
    Dim [Operator] As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles one_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles two_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles three_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles four_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles five_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles six_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles seven_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles eight_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles nine_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles zero_btn.Click
        txt_total.Text = txt_total.Text & sender.text
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles add_btn.Click
        firstval = Val(txt_total.Text)
        txt_total.Focus()
        [Operator] = "+"
        txt_total.Text = ""
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles minus_btn.Click
        firstval = Val(txt_total.Text)
        txt_total.Focus()
        [Operator] = "-"
        txt_total.Text = ""
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles divide_btn.Click
        firstval = Val(txt_total.Text)
        txt_total.Focus()
        [Operator] = "/"
        txt_total.Text = ""
    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles multiply_btn.Click
        firstval = Val(txt_total.Text)
        txt_total.Focus()
        [Operator] = "*"
        txt_total.Text = ""
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles equal_btn.Click
        Dim Result As Double
        secondval = Val(txt_total.Text)
        Select Case [Operator]
            Case = "+"
                result = firstval + secondval
                txt_total.Text = result.ToString()
            Case = "-"
                result = firstval - secondval
                txt_total.Text = result.ToString()
            Case = "*"
                result = firstval * secondval
                txt_total.Text = result.ToString()
            Case = "/"
                result = firstval / secondval
                txt_total.Text = result.ToString()

        End Select
    End Sub

    Private Sub clear_btn_Click(sender As Object, e As EventArgs) Handles clear_btn.Click
        txt_total.Text = ""

    End Sub
End Class
