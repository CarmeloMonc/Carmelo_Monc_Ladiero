﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.seven_btn = New System.Windows.Forms.Button()
        Me.eight_btn = New System.Windows.Forms.Button()
        Me.nine_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.four_btn = New System.Windows.Forms.Button()
        Me.five_btn = New System.Windows.Forms.Button()
        Me.six_btn = New System.Windows.Forms.Button()
        Me.slash_btn = New System.Windows.Forms.Button()
        Me.one_btn = New System.Windows.Forms.Button()
        Me.two_btn = New System.Windows.Forms.Button()
        Me.three_btn = New System.Windows.Forms.Button()
        Me.multiply_btn = New System.Windows.Forms.Button()
        Me.clear_btn = New System.Windows.Forms.Button()
        Me.zero_btn = New System.Windows.Forms.Button()
        Me.equal_btn = New System.Windows.Forms.Button()
        Me.minus_btn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt_total
        '
        Me.txt_total.Font = New System.Drawing.Font("Century", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total.Location = New System.Drawing.Point(107, 32)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.Size = New System.Drawing.Size(270, 30)
        Me.txt_total.TabIndex = 0
        '
        'seven_btn
        '
        Me.seven_btn.Location = New System.Drawing.Point(107, 79)
        Me.seven_btn.Name = "seven_btn"
        Me.seven_btn.Size = New System.Drawing.Size(63, 37)
        Me.seven_btn.TabIndex = 1
        Me.seven_btn.Text = "7"
        Me.seven_btn.UseVisualStyleBackColor = True
        '
        'eight_btn
        '
        Me.eight_btn.Location = New System.Drawing.Point(176, 79)
        Me.eight_btn.Name = "eight_btn"
        Me.eight_btn.Size = New System.Drawing.Size(63, 37)
        Me.eight_btn.TabIndex = 2
        Me.eight_btn.Text = "8"
        Me.eight_btn.UseVisualStyleBackColor = True
        '
        'nine_btn
        '
        Me.nine_btn.Location = New System.Drawing.Point(245, 79)
        Me.nine_btn.Name = "nine_btn"
        Me.nine_btn.Size = New System.Drawing.Size(63, 37)
        Me.nine_btn.TabIndex = 3
        Me.nine_btn.Text = "9"
        Me.nine_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.Location = New System.Drawing.Point(107, 208)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(63, 37)
        Me.add_btn.TabIndex = 4
        Me.add_btn.Text = "+"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'four_btn
        '
        Me.four_btn.Location = New System.Drawing.Point(107, 122)
        Me.four_btn.Name = "four_btn"
        Me.four_btn.Size = New System.Drawing.Size(63, 36)
        Me.four_btn.TabIndex = 5
        Me.four_btn.Text = "4"
        Me.four_btn.UseVisualStyleBackColor = True
        '
        'five_btn
        '
        Me.five_btn.Location = New System.Drawing.Point(176, 122)
        Me.five_btn.Name = "five_btn"
        Me.five_btn.Size = New System.Drawing.Size(63, 36)
        Me.five_btn.TabIndex = 6
        Me.five_btn.Text = "5"
        Me.five_btn.UseVisualStyleBackColor = True
        '
        'six_btn
        '
        Me.six_btn.Location = New System.Drawing.Point(245, 122)
        Me.six_btn.Name = "six_btn"
        Me.six_btn.Size = New System.Drawing.Size(63, 36)
        Me.six_btn.TabIndex = 7
        Me.six_btn.Text = "6"
        Me.six_btn.UseVisualStyleBackColor = True
        '
        'slash_btn
        '
        Me.slash_btn.Location = New System.Drawing.Point(245, 208)
        Me.slash_btn.Name = "slash_btn"
        Me.slash_btn.Size = New System.Drawing.Size(63, 37)
        Me.slash_btn.TabIndex = 8
        Me.slash_btn.Text = "/"
        Me.slash_btn.UseVisualStyleBackColor = True
        '
        'one_btn
        '
        Me.one_btn.Location = New System.Drawing.Point(107, 165)
        Me.one_btn.Name = "one_btn"
        Me.one_btn.Size = New System.Drawing.Size(63, 38)
        Me.one_btn.TabIndex = 9
        Me.one_btn.Text = "1"
        Me.one_btn.UseVisualStyleBackColor = True
        '
        'two_btn
        '
        Me.two_btn.Location = New System.Drawing.Point(176, 164)
        Me.two_btn.Name = "two_btn"
        Me.two_btn.Size = New System.Drawing.Size(63, 36)
        Me.two_btn.TabIndex = 10
        Me.two_btn.Text = "2"
        Me.two_btn.UseVisualStyleBackColor = True
        '
        'three_btn
        '
        Me.three_btn.Location = New System.Drawing.Point(245, 164)
        Me.three_btn.Name = "three_btn"
        Me.three_btn.Size = New System.Drawing.Size(63, 36)
        Me.three_btn.TabIndex = 11
        Me.three_btn.Text = "3"
        Me.three_btn.UseVisualStyleBackColor = True
        '
        'multiply_btn
        '
        Me.multiply_btn.Font = New System.Drawing.Font("Century", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.multiply_btn.Location = New System.Drawing.Point(316, 122)
        Me.multiply_btn.Name = "multiply_btn"
        Me.multiply_btn.Size = New System.Drawing.Size(61, 36)
        Me.multiply_btn.TabIndex = 12
        Me.multiply_btn.Text = "X"
        Me.multiply_btn.UseVisualStyleBackColor = True
        '
        'clear_btn
        '
        Me.clear_btn.Location = New System.Drawing.Point(316, 208)
        Me.clear_btn.Name = "clear_btn"
        Me.clear_btn.Size = New System.Drawing.Size(61, 37)
        Me.clear_btn.TabIndex = 13
        Me.clear_btn.Text = "C"
        Me.clear_btn.UseVisualStyleBackColor = True
        '
        'zero_btn
        '
        Me.zero_btn.Location = New System.Drawing.Point(316, 79)
        Me.zero_btn.Name = "zero_btn"
        Me.zero_btn.Size = New System.Drawing.Size(61, 37)
        Me.zero_btn.TabIndex = 14
        Me.zero_btn.Text = "0"
        Me.zero_btn.UseVisualStyleBackColor = True
        '
        'equal_btn
        '
        Me.equal_btn.Location = New System.Drawing.Point(176, 208)
        Me.equal_btn.Name = "equal_btn"
        Me.equal_btn.Size = New System.Drawing.Size(63, 37)
        Me.equal_btn.TabIndex = 15
        Me.equal_btn.Text = "="
        Me.equal_btn.UseVisualStyleBackColor = True
        '
        'minus_btn
        '
        Me.minus_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minus_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.minus_btn.Location = New System.Drawing.Point(316, 165)
        Me.minus_btn.Name = "minus_btn"
        Me.minus_btn.Size = New System.Drawing.Size(61, 37)
        Me.minus_btn.TabIndex = 16
        Me.minus_btn.Text = "-"
        Me.minus_btn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.minus_btn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(509, 366)
        Me.Controls.Add(Me.minus_btn)
        Me.Controls.Add(Me.equal_btn)
        Me.Controls.Add(Me.zero_btn)
        Me.Controls.Add(Me.clear_btn)
        Me.Controls.Add(Me.multiply_btn)
        Me.Controls.Add(Me.three_btn)
        Me.Controls.Add(Me.two_btn)
        Me.Controls.Add(Me.one_btn)
        Me.Controls.Add(Me.slash_btn)
        Me.Controls.Add(Me.six_btn)
        Me.Controls.Add(Me.five_btn)
        Me.Controls.Add(Me.four_btn)
        Me.Controls.Add(Me.add_btn)
        Me.Controls.Add(Me.nine_btn)
        Me.Controls.Add(Me.eight_btn)
        Me.Controls.Add(Me.seven_btn)
        Me.Controls.Add(Me.txt_total)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_total As TextBox
    Friend WithEvents seven_btn As Button
    Friend WithEvents eight_btn As Button
    Friend WithEvents nine_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents four_btn As Button
    Friend WithEvents five_btn As Button
    Friend WithEvents six_btn As Button
    Friend WithEvents slash_btn As Button
    Friend WithEvents one_btn As Button
    Friend WithEvents two_btn As Button
    Friend WithEvents three_btn As Button
    Friend WithEvents multiply_btn As Button
    Friend WithEvents clear_btn As Button
    Friend WithEvents zero_btn As Button
    Friend WithEvents equal_btn As Button
    Friend WithEvents minus_btn As Button
End Class
