﻿Public Class Form1
    Dim firstval As Double
    Dim secondval As Double
    Dim [operator] As String
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles nine_btn.Click


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles seven_btn.Click


    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles multiply_btn.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub one_btn_Click(sender As Object, e As EventArgs) Handles one_btn.

    End Sub

    Private Sub one_btn_Click_1(sender As Object, e As EventArgs) Handles one_btn.Click
        total_txtbox.Text = total_txtbox.Test & sender.text

    End Sub

    Private Sub two_btn_Click(sender As Object, e As EventArgs) Handles two_btn.Click


    End Sub

    Private Sub three_btn_Click(sender As Object, e As EventArgs) Handles three_btn.Click

    End Sub

    Private Sub four_btn_Click(sender As Object, e As EventArgs) Handles four_btn.Click

    End Sub

    Private Sub five_btn_Click(sender As Object, e As EventArgs) Handles five_btn.Click


    End Sub

    Private Sub six_btn_Click(sender As Object, e As EventArgs) Handles six_btn.Click

    End Sub

    Private Sub eight_btn_Click(sender As Object, e As EventArgs) Handles eight_btn.Click

    End Sub

    Private Sub txt_total_TextChanged(sender As Object, e As EventArgs) Handles txt_total.TextChanged

    End Sub
End Class
