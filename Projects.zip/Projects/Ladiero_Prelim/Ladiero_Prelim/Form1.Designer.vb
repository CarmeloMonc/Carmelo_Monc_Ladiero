﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Calculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.seven_btn = New System.Windows.Forms.Button()
        Me.eight_btn = New System.Windows.Forms.Button()
        Me.nine_btn = New System.Windows.Forms.Button()
        Me.multiply_btn = New System.Windows.Forms.Button()
        Me.four_btn = New System.Windows.Forms.Button()
        Me.five_btn = New System.Windows.Forms.Button()
        Me.six_btn = New System.Windows.Forms.Button()
        Me.minus_btn = New System.Windows.Forms.Button()
        Me.one_btn = New System.Windows.Forms.Button()
        Me.two_btn = New System.Windows.Forms.Button()
        Me.three_btn = New System.Windows.Forms.Button()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.divide_btn = New System.Windows.Forms.Button()
        Me.zero_btn = New System.Windows.Forms.Button()
        Me.equal_btn = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt_total
        '
        Me.txt_total.Font = New System.Drawing.Font("Century", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total.Location = New System.Drawing.Point(122, 63)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.Size = New System.Drawing.Size(210, 33)
        Me.txt_total.TabIndex = 0
        '
        'seven_btn
        '
        Me.seven_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.seven_btn.Location = New System.Drawing.Point(122, 132)
        Me.seven_btn.Name = "seven_btn"
        Me.seven_btn.Size = New System.Drawing.Size(48, 38)
        Me.seven_btn.TabIndex = 1
        Me.seven_btn.Text = "7"
        Me.seven_btn.UseVisualStyleBackColor = True
        '
        'eight_btn
        '
        Me.eight_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eight_btn.Location = New System.Drawing.Point(176, 132)
        Me.eight_btn.Name = "eight_btn"
        Me.eight_btn.Size = New System.Drawing.Size(48, 38)
        Me.eight_btn.TabIndex = 2
        Me.eight_btn.Text = "8"
        Me.eight_btn.UseVisualStyleBackColor = True
        '
        'nine_btn
        '
        Me.nine_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nine_btn.Location = New System.Drawing.Point(230, 132)
        Me.nine_btn.Name = "nine_btn"
        Me.nine_btn.Size = New System.Drawing.Size(48, 38)
        Me.nine_btn.TabIndex = 3
        Me.nine_btn.Text = "9"
        Me.nine_btn.UseVisualStyleBackColor = True
        '
        'multiply_btn
        '
        Me.multiply_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.multiply_btn.Location = New System.Drawing.Point(284, 132)
        Me.multiply_btn.Name = "multiply_btn"
        Me.multiply_btn.Size = New System.Drawing.Size(48, 38)
        Me.multiply_btn.TabIndex = 4
        Me.multiply_btn.Text = "*"
        Me.multiply_btn.UseVisualStyleBackColor = True
        '
        'four_btn
        '
        Me.four_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.four_btn.Location = New System.Drawing.Point(122, 176)
        Me.four_btn.Name = "four_btn"
        Me.four_btn.Size = New System.Drawing.Size(48, 38)
        Me.four_btn.TabIndex = 5
        Me.four_btn.Text = "4"
        Me.four_btn.UseVisualStyleBackColor = True
        '
        'five_btn
        '
        Me.five_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.five_btn.Location = New System.Drawing.Point(176, 176)
        Me.five_btn.Name = "five_btn"
        Me.five_btn.Size = New System.Drawing.Size(48, 38)
        Me.five_btn.TabIndex = 6
        Me.five_btn.Text = "5"
        Me.five_btn.UseVisualStyleBackColor = True
        '
        'six_btn
        '
        Me.six_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.six_btn.Location = New System.Drawing.Point(230, 176)
        Me.six_btn.Name = "six_btn"
        Me.six_btn.Size = New System.Drawing.Size(48, 38)
        Me.six_btn.TabIndex = 7
        Me.six_btn.Text = "6"
        Me.six_btn.UseVisualStyleBackColor = True
        '
        'minus_btn
        '
        Me.minus_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minus_btn.Location = New System.Drawing.Point(284, 176)
        Me.minus_btn.Name = "minus_btn"
        Me.minus_btn.Size = New System.Drawing.Size(48, 38)
        Me.minus_btn.TabIndex = 8
        Me.minus_btn.Text = "-"
        Me.minus_btn.UseVisualStyleBackColor = True
        '
        'one_btn
        '
        Me.one_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.one_btn.Location = New System.Drawing.Point(122, 220)
        Me.one_btn.Name = "one_btn"
        Me.one_btn.Size = New System.Drawing.Size(48, 38)
        Me.one_btn.TabIndex = 9
        Me.one_btn.Text = "1"
        Me.one_btn.UseVisualStyleBackColor = True
        '
        'two_btn
        '
        Me.two_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.two_btn.Location = New System.Drawing.Point(176, 220)
        Me.two_btn.Name = "two_btn"
        Me.two_btn.Size = New System.Drawing.Size(48, 38)
        Me.two_btn.TabIndex = 10
        Me.two_btn.Text = "2"
        Me.two_btn.UseVisualStyleBackColor = True
        '
        'three_btn
        '
        Me.three_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.three_btn.Location = New System.Drawing.Point(230, 220)
        Me.three_btn.Name = "three_btn"
        Me.three_btn.Size = New System.Drawing.Size(48, 38)
        Me.three_btn.TabIndex = 11
        Me.three_btn.Text = "3"
        Me.three_btn.UseVisualStyleBackColor = True
        '
        'add_btn
        '
        Me.add_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.add_btn.Location = New System.Drawing.Point(284, 220)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(48, 38)
        Me.add_btn.TabIndex = 12
        Me.add_btn.Text = "+"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'divide_btn
        '
        Me.divide_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.divide_btn.Location = New System.Drawing.Point(122, 264)
        Me.divide_btn.Name = "divide_btn"
        Me.divide_btn.Size = New System.Drawing.Size(48, 38)
        Me.divide_btn.TabIndex = 13
        Me.divide_btn.Text = "/"
        Me.divide_btn.UseVisualStyleBackColor = True
        '
        'zero_btn
        '
        Me.zero_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zero_btn.Location = New System.Drawing.Point(176, 264)
        Me.zero_btn.Name = "zero_btn"
        Me.zero_btn.Size = New System.Drawing.Size(48, 38)
        Me.zero_btn.TabIndex = 14
        Me.zero_btn.Text = "0"
        Me.zero_btn.UseVisualStyleBackColor = True
        '
        'equal_btn
        '
        Me.equal_btn.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equal_btn.Location = New System.Drawing.Point(284, 264)
        Me.equal_btn.Name = "equal_btn"
        Me.equal_btn.Size = New System.Drawing.Size(48, 38)
        Me.equal_btn.TabIndex = 15
        Me.equal_btn.Text = "="
        Me.equal_btn.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(230, 264)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(48, 38)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "C"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 381)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.equal_btn)
        Me.Controls.Add(Me.zero_btn)
        Me.Controls.Add(Me.divide_btn)
        Me.Controls.Add(Me.add_btn)
        Me.Controls.Add(Me.three_btn)
        Me.Controls.Add(Me.two_btn)
        Me.Controls.Add(Me.one_btn)
        Me.Controls.Add(Me.minus_btn)
        Me.Controls.Add(Me.six_btn)
        Me.Controls.Add(Me.five_btn)
        Me.Controls.Add(Me.four_btn)
        Me.Controls.Add(Me.multiply_btn)
        Me.Controls.Add(Me.nine_btn)
        Me.Controls.Add(Me.eight_btn)
        Me.Controls.Add(Me.seven_btn)
        Me.Controls.Add(Me.txt_total)
        Me.Name = "Calculator"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_total As TextBox
    Friend WithEvents seven_btn As Button
    Friend WithEvents eight_btn As Button
    Friend WithEvents nine_btn As Button
    Friend WithEvents multiply_btn As Button
    Friend WithEvents four_btn As Button
    Friend WithEvents five_btn As Button
    Friend WithEvents six_btn As Button
    Friend WithEvents minus_btn As Button
    Friend WithEvents one_btn As Button
    Friend WithEvents two_btn As Button
    Friend WithEvents three_btn As Button
    Friend WithEvents add_btn As Button
    Friend WithEvents divide_btn As Button
    Friend WithEvents zero_btn As Button
    Friend WithEvents equal_btn As Button
    Friend WithEvents Button1 As Button
End Class
